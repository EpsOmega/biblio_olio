$(document).ready(function(){  
function get_search_results_from_URL() {//startvalue =0  this querystr looks like 
var thisURL= 'https://hartford.waldo.kohalibrary.com/api/opac/(note%3A%22new%20psy%2018%22%20OR%20note%3A%22new%20psy%2017%22%20OR%20note%3A%22new%20psy%2016%22)?count=200&embed=200&facet.field=owned-by&facet.field=collection&facet.field=author-display&facet.field=topic_facet&facet.field=pubyear&facet.field=language&facet.field=geo_facet&fq=lost:*&sort=acqdate+desc&spellcheck=true&spellcheck.collate=true&spellcheck.count=10&spellcheck.maxCollations=10&start=0';

 //  console.log("URL",querystr);
  // console.log("thisURL",thisURL);
  $.getJSON(thisURL + '&callback=?' ,function(json){
       console.log(json);   
  });   
}//func

get_search_results_from_URL();

});