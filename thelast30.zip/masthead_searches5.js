//This Javascript file is needed for Masthead Searches. This works in tandem with HTML code located in logo.html
/*
<!-- Begin Masthead Searches Below This Line -->
<div id="rwd-search-form">
HTML code is located here and is found in logo.html
</div><!-- <div id="rwd-search-form"> --> 
<!-- End Masthead Searches above This Line --> 
*/

//Define first <SELECT> Options
var selone_arr = {
"0": "",
"1": "title:",
"2": "author:",
"3": "subject:",
"4": "isbn:",
"5": "series-title:",
"6": "callnumber:",
"7": "concept:",
"8": "text-fl:"
};

//Define second <SELECT> Options
var seltwo_arr = {
"0": "",
"1": "?fq=collection:BOOK%20OR%20collection:THESES",
"2": "?fq=collection:THESES",
"3": "?fq=collection:SCORES%20OR%20itemtype:SCORECD",
"4": "?fq=itemtype:MINISCORE%20OR%20itemtype:MINISCORE4%20OR%20itemtype:SC%20OR%20itemtype:SCORE%20OR%20itemtype:SCORE4%20OR%20itemtype:SCORENC%20OR%20itemtype:SCPT%20OR%20itemtype:SCPTNC%20OR%20itemtype:VSCORE%20OR%20itemtype:VSCORE4%20OR%20itemtype:VSCORENC%20OR%20itemtype:SCORECD",
"5": "?fq=itemtype:PARTS%20OR%20itemtype:PARTS4%20OR%20itemtype:PARTSNC%20OR%20itemtype:SC%20OR%20itemtype:SCPT%20OR%20itemtype:SCPT4%20OR%20itemtype:SCPTNC%20OR%20itemtype:HARTTORCH",
"6": "?fq=collection:AUDIOCD%20OR%20collection:LPS%20OR%20collection:AUDIOCASSE%20OR%20collection:MIXEDMEDIA%20OR%20itemtype:SCORECD",
"7": "?fq=collection:AUDIOCD%20OR%20itemtype:SCORECD",
"8": "?fq=collection:LPS",
"9": "?fq=collection:DVD%20OR%20collection:VHS%20OR%20collection:MIXEDMEDIA",
"10": "?fq=collection:DVD",
"11": "?fq=collection:VHS",
"12": "?fq=collection:PERIODICAL%20OR%20collection:NEWSPAPERS",
"13": "?fq=collection:E-RESOURCE%20OR%20itemtype:ELECRES",
"14": "?fq=location:RESERVES%20AND%20on-shelf-at:MORTENSEN",
"15": "?fq=location:RESERVES%20AND%20on-shelf-at:ALLEN",
"16": "?fq=location:CURRLAB",
"17": "?fq=location:JUDAICA%20OR%20location:JUDOVER",
"18": "?fq=on-shelf-at:PERFLIB"
};
//7 = ...just CDs
$(document).ready(function(){

  function KOHAfix(str) {
  str=str.trim();
  console.log( "str=str.trim()",str );
  str=str.replace(/[=:;|&!'()/]/g, '').replace(/[?]/g, '%3F').trim();
  console.log( "FINAL for SOLR str=",str );
  return str;
  }//eof KOHAfix(str)

  function buildURL() { // Build the URL for Solr and also send that URL to Solr

    var seloneFT = selone_arr[$('#selone').find("option:selected").val()];  //Ex. "series-title:"
    //console.log("seloneFT",seloneFT);

    var userinputqueryFT= $('#userinputquery').val();
    //console.log("userinputqueryFT",userinputqueryFT);

    if( userinputqueryFT.length === 0 ) {
       userinputqueryFT="*";
     }else{
  	 userinputqueryFT= KOHAfix(userinputqueryFT);  //Fix the user input query string before passing it to Solr
     console.log("userinputqueryFT",userinputqueryFT);
    }//if

    var seltwoFT = seltwo_arr[$('#seltwo').find("option:selected").val()]; //Ex. "?fq=collection:THESES"
    //console.log("seltwoFT",seltwoFT);

    var theDomain= 'https://hartford.waldo.kohalibrary.com/'; // or var theDomain ='';  use '' in production

    var url4Solr= theDomain + 'api/opac/' + seloneFT + '(' + userinputqueryFT  + ')' + seltwoFT;

var extended_params='count=20&embed=3&facet.field=owned-by&facet.field=collection&facet.field=author-display&facet.field=topic_facet&facet.field=pubyear&\
facet.field=language&facet.field=geo_facet&fq=lost:*&spellcheck=true&spellcheck.collate=true&spellcheck.count=10&spellcheck.maxCollations=10&start=0';

$.getJSON(url4Solr + '?' + extended_params + 'callback=?',function(json){
  $('#mc').empty();
  console.log(json.hits.length);
  console.log(json.hits);
});


  }// eof function buildURL() {


  $('#selone').on('change', function() {
    console.log( this.value );
  });


  $('#seltwo').on('change', function() {
    console.log( this.value );
  });


  $("#go").click(function(e){
    e.preventDefault();	
    console.log("#go - just clicked");
    buildURL();
  });


  $("#cres").click(function(e){
   e.preventDefault();	
    $('#debugarea').html('');
  });

});//eof $(document).ready(function(){ 

//https://hartford.waldo.kohalibrary.com/api/opac/(helping)?count=20&embed=3&facet.field=owned-by&facet.field=collection&facet.field=author-display&facet.field=topic_facet&facet.field=pubyear&facet.field=language&facet.field=geo_facet&fq=lost:*&spellcheck=true&spellcheck.collate=true&spellcheck.count=10&spellcheck.maxCollations=10&start=0  